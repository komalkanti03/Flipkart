from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required



# Create your views here.
def Signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return render(request, 'home.html')
        else:
            messages.error(request, 'Invalid form submission. Please try again')
    else:
        form = UserCreationForm()
    return render(request, 'Signup.html',{'form':form})


def Signin(request): 
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request,user)
            return render('login')
        else:
            messages.error(request,'Invalid form Submission. Please try again.')
    else:
        form = UserCreationForm
    return render(request,'Signin.html',{'form':form})




def Logout(request):
    logout(request)
    return redirect('login')